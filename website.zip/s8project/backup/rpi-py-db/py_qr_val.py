#!/usr/bin/env python

z=6355433174366815
print(z)
